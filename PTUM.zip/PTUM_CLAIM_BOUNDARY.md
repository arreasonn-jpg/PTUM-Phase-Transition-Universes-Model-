# PTUM Claim Boundary v1.1 CLEAN

## Safe core claim

PTUM is an effective phenomenological cosmological framework in which a threshold-triggered discharge event can generate a dark-matter candidate sector, a residual near-Lambda dark-energy-like sector, and a proxy-fluid dark-radiation component.

The sharp observational discriminator is the difference between fluid-like dark radiation and free-streaming relativistic species. In the effective linear proxy-fluid closure, the pfd component has

```text
w = 1/3, c_s^2 = 1/3, sigma = 0
```

and therefore does not produce the neutrino-like CMB acoustic phase shift associated with free-streaming radiation.

## Current-data status

The benchmark analysis gives

```text
Delta chi^2 = -0.26
Delta AIC = +2.26
Delta N_fluid < 0.31 at 95% credibility
```

This should be framed as follows:

```text
Current data show a weak preference for LambdaCDM while leaving PTUM viable as a falsifiable effective extension.
```

It should not be framed as positive evidence that current data prefer PTUM.

## Claims intentionally not made

PTUM does not claim to be:

- a UV-complete derivation of the pre-discharge background,
- a solution of the cosmological-constant problem,
- a unique microscopic theory of the dark sector,
- a replacement for LambdaCDM already favored by current data,
- a proof of any external cross-project mechanism.

## v1.1 cleanup

All external cross-project terminology has been removed from the PTUM manuscript. The paper now stands as a self-contained effective cosmology model.


## v1.2 corrected code-availability update

The exact public repository is:

```text
https://github.com/ErdemEsa/ptum-cosmology.git
```

The repository contains the public PTUM `CLASS v3.2.0` patch. This supports a code-availability claim for the core Boltzmann-code implementation. It does not by itself complete the full public Bayesian pipeline, because production Cobaya YAML files and full MCMC chains remain pending or external-archive items.
